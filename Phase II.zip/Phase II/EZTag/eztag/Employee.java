/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eztag;

/**
 *
 * @author jjred88
 */

//import java.io.*;
//import java.util.*;

public class Employee extends Account {
    
    //Constructor
    public Employee(String uName, String pass, String fName, String lName, String address) {
        super(uName, pass, fName, lName, address);
    }
    
    
    
}
